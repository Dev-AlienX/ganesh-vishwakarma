app.directive('navBar', function () {
  return {
    templateUrl: 'app/directive/view/navbar.html',
    controller  : 'navbarController'
  }
});
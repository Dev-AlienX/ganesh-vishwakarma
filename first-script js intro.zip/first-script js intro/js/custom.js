function firstDemo() {
  var a = 'Date & time is';
  document.getElementById('demo').innerHTML = Date();
  document.getElementById('btn-txt').innerHTML = a;
  document.getElementsByClassName('demo')[0].innerHTML = Date();
}

var a = 10;
var b = 20;
var c = a + b;
var d = a * b;

function SecendDemo1() {
  document.getElementById('demo3').innerHTML = c;
}

function SecendDemo2() {
  document.getElementById('demo3').innerHTML = d;
}

function chengeStyle() {
  document.getElementById('demo4').style.backgroundColor = 'aqua';
}

function ShowDisplay() {
  document.getElementById('demo5').style.display = 'inline-block';
}

function firstDemo2() {
  document.getElementById('demo6').innerHTML = Date();
}

function alertIt() {
  window.alert('stay cool :-)');
}

function ShowItInLog() {
  console.log('i am log for that click');
}

function myName() {
  var name;
  name = 'Ganesh Vishwakarma';
  document.getElementById('demo7').innerHTML = name;
}

var a = myTempFunction(5, 9);
var b = "Hello there";
var c = b.length;
document.getElementById("demo8").innerHTML = a + " this value is returned by function";

function myTempFunction(r, t) {
  return r * t;
}

function cToF(celsius) {
  var cTemp = celsius;
  var cToFahr = cTemp * 9 / 5 + 32;
  var message = cTemp + ' C is ' + Math.round(cToFahr) + ' F.';
  document.getElementById('demo9').innerHTML = message;
}

function fToC(fahrenheit) {
  var fTemp = fahrenheit;
  var fToCel = (fTemp - 32) * 5 / 9;
  var message = fTemp + ' F is ' + Math.round(fToCel) + ' C.';
  document.getElementById('demo10').innerHTML = message;
}

function myCar() {
  // var car = {type:"Fiat", model:"500", color:"white"};
  var car = {
    name: "ford",
    model: "GT",
    color: "red",
    price: "aukat se bahar abhi"
  };
  document.getElementById('demo11').innerHTML = "car name: " + car["name"] + " " + car.model + "<br>" + "color: " + car.color + "<br>" + " kimat :" + car.price;
}

function myNewCar() {
  var car = {
    name: "ford",
    model: "GT",
    color: "red",
    price: "aukat se bahar abhi",
    carName: function () {
      return this.name +
        " " +
        this.model;
    }
  };
  document.getElementById('demo12').innerHTML = 
  "car name: " + car.carName() 
  + "<br>" + "color: " 
  + car.color + "<br>" 
  + " kimat :" + car.price;
}

var testString = "hi there I am going to test some string";
var a = testString.indexOf("I");
var b = testString.search(" test");
var res = testString.slice(9, 14);
var n = testString.replace("hi", "hello");
var text2 = testString.toUpperCase();
var text3 = res.concat(" ", a);
var txt2 = "a,b,c,d,e"; 
 document.getElementById('demo13').innerHTML = testString;
 document.getElementById('demo13.1').innerHTML= a;
 document.getElementById('demo13.2').innerHTML = b;
 document.getElementById('demo13.3').innerHTML = res;
 document.getElementById('demo13.4').innerHTML = n;
 document.getElementById('demo1305').innerHTML = text2;
 document.getElementById('demo13.6').innerHTML = text3;
 document.getElementById('demo13.7').innerHTML = testString.charCodeAt(9);
 document.getElementById('demo13.8').innerHTML = txt2.split(" ");
 var cars = ["Saab", "Volvo", "BMW", "Ford", "tata", "honda"];
 function aryTest() {
  
  document.getElementById("demo13.0.1").innerHTML = cars;
  document.getElementById("demo13.0.2").innerHTML = cars.sort();
  document.getElementById("demo13.0.5").innerHTML = cars.reverse();
  cars.push("dodge");
  document.getElementById("demo13.0.3").innerHTML = cars;
  cars.pop("/saab/i");
  document.getElementById("demo13.0.4").innerHTML = cars;
 }
 var a1 = "200";
 var a2 = "100";
 var a7 = 10.6;
 var a8 = 5.4;
 var a3 = a1 + a2;
 var a4 = a1 * a2;
 var a5 = a1 / a2;
 var a6 = a1 - a2;
 document.getElementById('demo14').innerHTML = a3;
 document.getElementById('demo14.1').innerHTML = a4;
 document.getElementById('demo14.2').innerHTML = a5;
 document.getElementById('demo14.3').innerHTML = a6;
 document.getElementById('demo15.0').innerHTML = Math.round(a7);
 document.getElementById('demo15.1').innerHTML = Math.pow(a8, 2);
 document.getElementById('demo15.2').innerHTML = Math.sqrt(16);
 document.getElementById('demo15.3').innerHTML = Math.ceil(a8);
 document.getElementById('demo15.4').innerHTML = Math.floor(Math.random() * 10);

 function getAbout() {
  var age, voteable;
  age = Number(document.getElementById("age").value);
  Math.floor(age);
  if (isNaN(age)) {
    voteable = "Input is not a number";
  } else {
    voteable = (age < 18) ? "'18 ke baad voot karna'" : "'voter id banaya ki nahi !'";
  }
  document.getElementById("demo16").innerHTML = voteable;
  document.getElementById("demo16.1").innerHTML = " Your age is : " + age;
}

var i = 0;
var text = "";
while (cars[i]) {
  text += cars[i] + " ";
  i++;  
}
document.getElementById("demo17").innerHTML = text;

try {
  var adddlert = ""
  adddlert("Welcome guest!");
}
catch(err) {
  document.getElementById("demo18").innerHTML = err.message;
}

try {
  adddler("Welcome guest!");
}
catch(err) {
  document.getElementById("demo1801").innerHTML = err.message;
}

function myFun() {
  var message, x;
  message = document.getElementById("demo19");
  message.innerHTML = "";
  x = document.getElementById("demoinp").value;
  try { 
    if(x == "")  throw "empty";
    if(isNaN(x)) throw "not a number";
    x = Number(x);
    if(x < 5)  throw "too low";
    if(x > 10)   throw "too high";
  }
  catch(err) {
    message.innerHTML = "Input is " + err;
  }
}
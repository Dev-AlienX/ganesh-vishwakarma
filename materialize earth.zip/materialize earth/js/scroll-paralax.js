// scroll
$(document).ready(function () {
    $('.slider').slider({ full_width: true });
  });
  
  
  // Or with jQuery
  
  $(document).ready(function () {
    $('.parallax').parallax();
  });
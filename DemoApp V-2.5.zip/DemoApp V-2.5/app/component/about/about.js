app.controller('about', function($scope) {
    $scope.msg = 'i designe and beautify web pages.';
});
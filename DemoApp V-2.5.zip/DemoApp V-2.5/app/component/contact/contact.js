app.controller('contact', function($scope) {
    $scope.user = 'Alien X';
    $scope.userName = 'AlienX';
    $scope.email = 'Alien.x@Ben.com';
    $scope.msg = "";
});
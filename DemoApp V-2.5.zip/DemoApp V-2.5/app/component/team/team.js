app.controller('team', ['$scope','$http', function ($scope, $http) {
    // variable that saves data fron json using get
    var request = {
        method: 'get',
        url: 'http://localhost:3000/employeDetail',
        dataType: 'json',
        contentType: "application/json"
    }

    // empty array refrence
    $scope.employeDetail = new Array;

    // store request data to employeDetail array object
    $http(request).success(function (jsonData) {
            $scope.employeDetail = jsonData;
            $scope.list = $scope.employeDetail;
        })
        .error(function () {
    })

    // empty object
    $scope.employelist = {};
    // to save data to object 
    $scope.addData = function (employeDetails) {
        $scope.employeDetail.push(employeDetails);
        $scope.employeDetails = {};
    }

    // to edit selected data
    $scope.editData = function (index) {
        $scope.editId = index;
        $scope.employeDetails = $scope.employeDetail[index];
    }

    // to update selected data
    $scope.upadteData = function (employeDetails) {
        $scope.employeDetail[$scope.editId] = employeDetails;
        $scope.editId = undefined;
        $scope.employeDetails = {};
    }

    // to delete data from row
    $scope.deleteData = function (index) {
        $scope.employeDetail.splice(index, 1);
    }

    // to show and hide save and update button
    $scope.showMe = true;
    $scope.hideMe = true;
    // it will hide update btn and show save btn
    $scope.toggleUpdate = function () {
        $scope.showMe = true;
        $scope.hideMe = true;
    };
    // it will show update btn and hide save btn
    $scope.toggleEdit = function () {
        $scope.hideMe = !$scope.hideMe;
        $scope.showMe = !$scope.showMe;
    };
}]);
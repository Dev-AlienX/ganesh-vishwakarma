app.controller('home', function($scope) {
    // create a message to display in view
    $scope.message = 'How are you ?';
});
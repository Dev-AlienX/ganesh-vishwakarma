$(window).scroll(function() {
    if ($(document).scrollTop() > 100) {
      $('nav').addClass('smallNav');
      $('nav').removeClass('bigNav');
    } else {
        $('nav').addClass('bigNav');
        $('nav').removeClass('smallNav');
    }
    
});



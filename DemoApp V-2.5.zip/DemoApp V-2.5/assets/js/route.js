app.config(function($routeProvider) {
    $routeProvider

        // route for the home page
        .when('/', {
            templateUrl : 'app/component/home/home.htm',
            controller  : 'home'
        })

        // route for the about page
        .when('/about', {
            templateUrl : 'app/component/about/about.htm',
            controller  : 'about'
        })

        // route for the team page
        .when('/team', {
            templateUrl : 'app/component/team/team.htm',
            controller  : 'team'
        })
        // route for the contact page
        .when('/contact', {
            templateUrl : 'app/component/contact/contact.htm',
            controller  : 'contact'
        })
        .otherwise({
            redirectTo: '/'
        });
});
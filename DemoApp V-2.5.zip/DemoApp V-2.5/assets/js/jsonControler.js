// app.controller('jsonController', function ($scope, $http) {
//     var request = {
//         method: 'get',
//         url: 'app/data/data.json',
//         dataType: 'json',
//         contentType: "application/json"
//     };

//     $scope.employeDetail = new Array;

//     $http(request)
//         .success(function (jsonData) {
//             $scope.employeDetail = jsonData;
//             $scope.list = $scope.employeDetail;
//         })
//         .error(function () {

//         });
// });
let hidden = false;
let titleOnTop = false;

window.onscroll = function () {
  scrollFunction()
};

function scrollFunction() {
  // debugger

  // if (document.getElementsByClassName('hero-title')[0].getBoundingClientRect().top <= -250) {
  //   titleOnTop = true;
  //   titleToTop();
  // } else {
  //   titleOnTop = false;
  //   titleToTop();
  // }

  if (document.body.scrollTop > 150 || document.documentElement.scrollTop > 150) {
    document.querySelector('header').style.height = "70px";
    // document.querySelector('header').style.background = "white";
  } else {
    document.querySelector('header').style.height = "100px";

  }
}
// titleToTop = () => {
//   if (titleOnTop) {
//     document.getElementsByClassName('hero-title')[0].classList.add('fixedTop');
//   } else if (!titleOnTop) {
//     document.getElementsByClassName('hero-title')[0].classList.remove('fixedTop');
//   }
// }

toggleMenu = (event) => {
  if (!hidden) {
    document.getElementsByClassName('navs')[0].classList.add('hidden');
    document.getElementsByTagName('header')[0].style.borderBottom = "unset";
    document.getElementsByTagName('header')[0].style.background = "transparent";
    hidden = true;

  } else if (hidden) {
    document.getElementsByClassName('navs')[0].classList.remove('hidden');
    document.getElementsByTagName('header')[0].style.borderBottom = "2px solid #E04343";
    document.getElementsByTagName('header')[0].style.background = "white"
    hidden = false
  }
}
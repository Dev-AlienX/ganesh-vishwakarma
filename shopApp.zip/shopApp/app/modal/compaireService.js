app.factory('newCompare', function(){
    // debugger;
      var newCompare = {
        'list':[],
        
      };
      newCompare.add = function(){
        // debugger;
        // newCart.list.push($scope.cart);
      };
      return newCompare;
    });
app.directive('modalDialog', function () {
  return {
    restrict: 'E',
    scope: {
      show: '=',
      type: '=',
      msg: '=',
    },
    templateUrl: "app/directive/view/modelTmpl.html",
    transclude: false,
    link: function (scope, elem, attrs) {
      scope.hideModal = function () {
        scope.show = false;
      };
    }
  }
});

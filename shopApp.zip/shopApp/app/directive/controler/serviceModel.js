app.directive('notifyMe', function () {
  return {
    restrict: 'E',
    scope: false,
    templateUrl: "app/directive/view/modelTmpl.html",
    link: function (scope, elem, attrs) {
    }
  }
});
